ALTER TABLE generated_pins 
ADD COLUMN affiliate_link TEXT,
ADD COLUMN image_path VARCHAR(255);
